/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examhall;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Mehedi Hasan
 */
public class DBConnect {
    private static String userName;
    private static String Subject;
    public static Connection Connect() throws SQLException{
          Connection conn = null;
    try {
            // Load the MySQL JDBC driver
            String driverName = "com.mysql.jdbc.Driver";
            Class.forName(driverName);
            // Create a connection to the database
            String serverName = "localhost";
            String schema = "examhall";
            String url = "jdbc:mysql://" + serverName +  "/" + schema;
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(url, username, password);
            //System.out.println("Successfully Connected to the database!");
        } catch (ClassNotFoundException e) {
            System.out.println("Could not find the database driver " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Could not connect to the database " + e.getMessage());
        }
        return conn;
    }
    
    public static void setUsername(final String user){
        userName = user;
    }
    public static String getUsername(){
        return userName;
    }
    
    public static void setSubject(final String sub){
        Subject = sub;
    }
    public static String getSubject(){
        return Subject;
    }
}
