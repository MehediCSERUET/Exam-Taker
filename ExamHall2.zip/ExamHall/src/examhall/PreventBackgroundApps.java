/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examhall;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mehedi Hasan
 */
public class PreventBackgroundApps implements Runnable{
       public static List<String> Check() throws InterruptedException, IOException{
        Process process = new ProcessBuilder("tasklist.exe", "/fo", "csv", "/nh").start();
        List<String> processNames = new ArrayList<String>();
        
        int i = 0;
        Scanner sc = new Scanner(process.getInputStream());
        if (sc.hasNextLine()) sc.nextLine();
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] parts = line.split(",");
            String unq = parts[0].substring(1).replaceFirst(".$", "");
            String pid = parts[1].substring(1).replaceFirst(".$", "");
            String sessName = parts[2].substring(1).replaceFirst(".$", "");
            if(sessName.equals("Console")){
                processNames.add(unq);
            }
        }
        process.waitFor();
        //System.out.println("Done");
        return processNames;
    }
       
    public static void Kill(String processName) throws Exception
     {
             Process process = java.lang.Runtime.getRuntime().exec("taskkill /F /IM "+processName);
             //Process processPID = java.lang.Runtime.getRuntime().exec("taskkill /pid "+pid+" /f");
             int x = process.waitFor();
             if (x == 0) {
                     System.out.println("Process killed successfully");
             }
             else {
                     System.out.println("Error 1");
             }
     }
       
   public void run() {
       Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("explorer.exe", 1);
        map.put("ntoskrnl.exe", 1);
        map.put("WerFault.exe", 1);
        map.put("backgroundTaskHost.exe", 1);
        map.put("backgroundTransferHost.exe", 1);
        map.put("winlogon.exe", 1);
        map.put("wininit.exe", 1);
        map.put("csrss.exe", 1);
        map.put("lsass.exe", 1);
        map.put("smss.exe", 1);
        map.put("services.exe", 1);
        map.put("taskeng.exe", 1);
        map.put("taskhost.exe", 1);
        map.put("dwm.exe", 1);
        map.put("conhost.exe", 1);
        map.put("svchost.exe", 1);
        map.put("sihost.exe", 1);
        map.put("System", 1);
        map.put("Registry", 1);
        map.put("winlogon.exe", 1);
        map.put("fontdrvhost.exe", 1);
        map.put("NVDisplay.Container.exe", 1);
        map.put("NVIDIA Web Helper.exe", 1);
        map.put("SearchUI.exe", 1);
        map.put("RuntimeBroker.exe", 1);
        map.put("StartMenuExperienceHost.exe", 1);
        map.put("WindowsInternal.ComposableShell.Experiences.TextInput.InputApp.exe", 1);
        map.put("nvcontainer.exe", 1);
        map.put("igfxEM.exe", 1);
        map.put("dptf_helper.exe", 1);
        map.put("NVIDIA Share.exe", 1);
        map.put("Nexus.exe", 1);
        map.put("Rainmeter.exe", 1);
        map.put("IAStorIcon.exe", 1);
        map.put("dllhost.exe", 1);
        map.put("java.exe", 1);
        map.put("httpd.exe", 1);
        map.put("ShellExperienceHost.exe", 1);
        map.put("rundll32.exe", 1);
        map.put("CompPkgSrv.exe", 1);
        map.put("tasklist.exe", 1);
        map.put("googledrivesync.exe", 1);
        map.put("netbeans64.exe", 1);
        map.put("nvcontainer.exe", 1);
        map.put("ctfmon.exe", 1);
        map.put("nvsphelper64.exe", 1);
        map.put("Avro Keyboard.exe", 1);
        map.put("nvsphelper64.exe", 1);
        map.put("xampp-control.exe", 1);
        map.put("mysqld.exe", 1);
       String processName;
        
    while (true) {
      try {
        List<String> processes = Check();
        Iterator<String> it = processes.iterator();
        while (it.hasNext()) {
            processName = it.next();
            if(map.containsKey(processName)==false){
                System.out.println("Process Name: "+processName+"\n");
                Kill(processName);
            }
         } 
        Thread.sleep(1000);
      } catch (InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
      } catch (IOException ex) {
            Logger.getLogger(PreventBackgroundApps.class.getName()).log(Level.SEVERE, null, ex);
    }   catch (Exception ex) {
            Logger.getLogger(PreventBackgroundApps.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  }
}